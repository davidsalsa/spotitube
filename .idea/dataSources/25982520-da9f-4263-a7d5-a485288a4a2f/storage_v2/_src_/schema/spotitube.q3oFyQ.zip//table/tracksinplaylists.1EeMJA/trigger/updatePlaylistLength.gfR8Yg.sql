CREATE TRIGGER updatePlaylistLength
  AFTER INSERT
  ON tracksinplaylists
  FOR EACH ROW
  BEGIN 
    UPDATE playlists p 
    inner join tracksInPlaylists tp 
    SET p.length = (SELECT SUM(t.duration) FROM tracks t INNER JOIN tracksInPlaylists tp where t.id = tp.trackId and p.id = tp.playlistId) 
    WHERE p.id = tp.playlistId;
    END;

