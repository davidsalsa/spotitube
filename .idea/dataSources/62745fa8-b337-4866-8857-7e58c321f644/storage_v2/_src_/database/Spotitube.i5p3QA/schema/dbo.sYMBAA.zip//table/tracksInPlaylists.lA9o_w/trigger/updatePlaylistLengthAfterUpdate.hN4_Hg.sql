
-- Stored procedure that updates playlistObject length everytime a track gets added. This happens for every insert/update and delete
CREATE TRIGGER updatePlaylistLengthAfterUpdate
    ON tracksInPlaylists
    AFTER INSERT, DELETE, UPDATE
    AS BEGIN
    IF @@ROWCOUNT = 0 RETURN
    SET NOCOUNT ON
    BEGIN TRY
        UPDATE p
        SET p.length = (SELECT SUM(t.duration) FROM tracks t INNER JOIN tracksInPlaylists tp ON t.id = tp.trackId and p.id = tp.playlistId)
        FROM playlists p inner join tracksInPlaylists tp ON p.id = tp.playlistId;
    END TRY
    BEGIN CATCH
        ;THROW
    END CATCH
END
go

